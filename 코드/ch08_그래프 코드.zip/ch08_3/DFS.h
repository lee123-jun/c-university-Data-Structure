#pragma once
#include "adjList.h"
void DFS_adjList(graphType* g, int v);